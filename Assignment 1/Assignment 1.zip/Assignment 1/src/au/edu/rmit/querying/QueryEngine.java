package au.edu.rmit.querying;


public interface QueryEngine {
	public SearchResult getSearchResult(String term);
}
