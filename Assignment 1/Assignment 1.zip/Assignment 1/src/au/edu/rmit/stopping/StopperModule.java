package au.edu.rmit.stopping;

public interface StopperModule {

    public boolean isStopWord(String word);

}
